from django.contrib import admin
from .models import Inf

admin.site.register(Inf)
