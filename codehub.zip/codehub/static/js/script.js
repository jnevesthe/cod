document.addEventListener("DOMContentLoaded", function () {
    // Animação suave ao clicar em links com #
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener("click", function (e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute("href"));
            if (target) {
                target.scrollIntoView({
                    behavior: "smooth"
                });
            }
        });
    });

    // Clique no botão "Saiba Mais"
    const ctaButton = document.getElementById("cta-button");
    if (ctaButton) {
        ctaButton.addEventListener("click", function () {
            alert("Você será redirecionado para mais informações em breve!");
        });
    }

    // Mensagem de boas-vindas no console
    console.log("🚀 Bem-vindo à Página Bonita!");
});